/*
 *   Author:  J.A.Martin   <jamartin.dev@gmail.com>
 *   File:  module.c
 *   Architecture:  x86
 *   Module description:  Given a PID process and a Virtual Address, translate it to the Physical one.
 *                        IOCTL's are used to communicate the module with userland.
 */


#include <linux/module.h>         /*   Needed by modules                         */
#include <linux/kernel.h>         /*   Needed by KERN_INFO                       */
#include <linux/init.h>           /*   Needed by macros                          */
#include <asm/page.h>             /*   Needed by __pa() macro                    */
#include <linux/sched.h>          /*   Needed by "for_each_process" macro        */
#include <linux/moduleparam.h>    /*   Needed by module params                   */
#include <linux/mm.h>
#include <linux/fs.h>
#include <asm/pgtable.h>   
#include <linux/hardirq.h>
#include <linux/highmem.h>
#include <asm/io.h>
#include <asm/uaccess.h>
#include <linux/spinlock.h>
#include "module.h"

#define OK 0
#define NOM_MODUL "traductor_adreces"


//  Concurrent access control
static int modul_obert = 0;


//  Global Variables declaration
struct mm_struct * mm;
struct page *pagina;

pgd_t *pgd;
pmd_t *pmd;
pte_t *ptep , pte;
	
int pid_tmp = 0;
int *pid = &pid_tmp;

int pfn;



//  Module Functions
//  ----------------

//  Function called when a process try to open a module to access it
static int device_open(struct inode *inode, struct file *file)
{

	//  Only one process can access the module
	//  Prevent that other process can access it when it's opened by a process
	if (modul_obert)
		return -EBUSY;

	modul_obert++;
	
	try_module_get(THIS_MODULE);
	
	return OK;
}


//  Function called when the process close the access to the module
static int device_release(struct inode *inode, struct file *file)
{

	//  Now the module can be accessed by other processes
	modul_obert--;

	module_put(THIS_MODULE);
	
	return OK;
}


//  Function called when the process try to access the module ops using IOCTL mechanism
int device_ioctl(struct inode *inode, struct file *file, unsigned int ioctl_num, unsigned long * ioctl_param)
{		
    unsigned long va = 0;
	unsigned long pa;
    
	//  Change to IOCTL called
	switch (ioctl_num) {
	
	  case IOCTL_ENVIAR_PID:
		pid = (int *)ioctl_param;
		printk(KERN_INFO "PID process:     %i \n", pid );
		struct task_struct *task;
        for_each_process(task)  {
          if  ( task->pid == pid )  
		  {
	        mm = task->mm;
	      }
        }
		break;

	  case IOCTL_TRADUCTOR:
		va = (unsigned long *)ioctl_param;
		pa = 0;
		
		//  Variable initialization
		pagina = NULL;
	    pgd = NULL;
	    pmd = NULL;
	    ptep = NULL;
	
	    // Using Page Tables (this mechanism is known as "Page Walk"), we find the page that corresponds to Virtual Address
	    pgd  = pgd_offset(mm, va);
	    if ( !pgd_none(*pgd) || !pgd_bad(*pgd) )
	    {
	      pmd  = pmd_offset(pgd, va);
	      if ( !pmd_none(*pmd) || !pmd_bad(*pmd) )
	      {
		    ptep = pte_offset_map(pmd, va);
		    if (ptep)
		    {
	          pte  = *ptep;
		      pte_unmap(ptep);
              pagina = pte_page(pte);
			  
			  //  The page has been found
			  //  Seek "Page Frame Number" for this page
			  pfn = page_to_pfn(pagina);

			  //  Seek Physical Address for this page, using "page_to_phys()" macro
	          pa = page_to_phys(pagina);
		    }
			else   printk(KERN_INFO "Page Walk exception.  The Virtual Address has not been found for this process. \n" );
	      }
		  else   printk(KERN_INFO "Page Walk exception.  The Virtual Address has not been found for this process. \n" );
	    }
		else   printk(KERN_INFO "Page Walk exception.  The Virtual Address has not been found for this process. \n" );
		
		return pa;
		break;
		
	  case IOCTL_REBRE_PFN:
	    va = (unsigned long *)ioctl_param;
		return pfn;
	  
	  default:
	    return -ENOTTY;
	}

	return OK;
}


//   Module ops
struct file_operations ops = {
	.owner   =  THIS_MODULE,
	.read    =  NULL,
	.write   =  NULL,
	.ioctl   =  device_ioctl,
	.open    =  device_open,
	.release =  device_release,	
};



static int __init module_start(void)
{
  printk(KERN_INFO "Loading 'traductor_adreces' module ... \n");
  
  int init;
  init = register_chrdev(MAJOR_NUM, NOM_MODUL, &ops);
  
  if (init < 0)  
  {
    printk(KERN_ALERT "Error loading module 'traductor_adreces' \n");
	printk(KERN_ALERT "Error code:  %d \n" , init );
	return init;
  }
  else   
  {
    printk(KERN_INFO "Module loaded successfully \n");
	return 0;
  }
}
  
  
  
static void __exit module_end(void)
{
  printk(KERN_INFO "Unloading module 'traductor_adreces' ...\n");
  
  unregister_chrdev(MAJOR_NUM, NOM_MODUL);
  
}


module_init(module_start);
module_exit(module_end);


/*   Info sobre el modul   */
MODULE_AUTHOR ("J.A.Martin   <jamartin.dev@gmail.com>");
MODULE_DESCRIPTION ("Translate a Virtual Address to Physical one, using Page Tables");
MODULE_LICENSE("GPL");
