/*
 *   Author:  J.A.Martin   <jamartin.dev@gmail.com>
 *   File:  module.h
 *   Module description:  Given a PID process and a Virtual Address, translate it to the Physical one.
 *                        IOCTL's are used to communicate the module with userland.
 */

 
#ifndef MODULE_H
#define MODULE_H

#include <linux/ioctl.h>

#define MAJOR_NUM 100

#define IOCTL_ENVIAR_PID _IOR(MAJOR_NUM,  0 , int * )
#define IOCTL_TRADUCTOR  _IOWR(MAJOR_NUM, 1 , unsigned long * )
#define IOCTL_REBRE_PFN  _IOWR(MAJOR_NUM, 2 , unsigned long * )

#define DEVICE_FILE_NAME "traductor_adreces"

#endif
